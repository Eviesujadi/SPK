<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pembantu extends Model
{
    //
}
