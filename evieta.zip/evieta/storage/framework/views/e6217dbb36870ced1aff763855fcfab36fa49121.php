<div class="card">
    <div class="card-header">
        <h5>Tabel Kriteria</h5>
        <div class="card-header-right">    <ul class="list-unstyled card-option">        <li><i class="icofont icofont-simple-left "></i></li>        <li><i class="icofont icofont-maximize full-card"></i></li>        <li><i class="icofont icofont-minus minimize-card"></i></li>        <li><i class="icofont icofont-refresh reload-card"></i></li>        <li><a href="<?php echo e(route('datadasar.form_kriteria')); ?>"><i class="icofont icofont-plus"></i></a></li>    </ul></div>
    </div>
    <div class="card-block table-border-style">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Kriteria</th>
                        <th>Atribut</th>
                        <th>Bobot</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th><?php echo e($i + 1); ?></th>
                        <td><?php echo e($k->nama_kriteria); ?></td>
                        <td><?php echo e($k->atribut); ?>/td>
                        <td><?php echo e($k->bobot); ?></td>
                        <td><a href="<?php echo e(route('datadasar.form_alternatif')); ?>">Edit</a>  |  <a href="<?php echo e(route('datadasar.form_alternatif')); ?>">Hapus</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td>Data Tidak Ada</td>
                    </tr>
                 <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\evieta\resources\views/datadasar/file_kriteria.blade.php ENDPATH**/ ?>